# VORP-Hunting
- hunt animals and sell 
- sell big fish
- whole animals
- carcasses
- pelts
- pelts stored on the back of the horses
- NEW  you can get items to inventory when skinning them.

## Requirements
- [VORP-Core](https://github.com/VORPCORE/VORP-Core/releases)
- [VORP-Inputs](https://github.com/VORPCORE/VORP-Inputs/releases)
- [VORP-Character](https://github.com/VORPCORE/VORP-Character/releases)
- [VORP-Inventory](https://github.com/VORPCORE/VORP-Inventory/releases)

## How to install
* [Download VORP Hunting](https://github.com/VORPCORE/VORP-Hunting)
* Copy and paste ```vorp_hunting``` folder to ```resources/vorp_hunting```
* Add ```ensure vorp_hunting``` to your ```server.cfg``` file
* To change the language go to ```resources/vorp_hunting/config.lua```
* Now you are ready!

Credits to [zebbyskitzoo](https://github.com/OTRP) &amp; [CryptoGenics](https://github.com/CryptoGenics) for the original config and also to [Local9](https://github.com/Local9) for potential fix.

 [Spreadsheet](https://docs.google.com/spreadsheets/d/1d9VQXdl8JS76N6OFf541MN1R0XMHI2f9PHPLiJapru8/edit?usp=sharing) for easy adding animals
